"""Mutilated chessboard problem."""

import argparse
from functools import reduce
from cudd import Cudd, REORDER_SIFT_CONVERGE

def check_positive_number(value):
    """Check that the argument is a positive integer."""
    ivalue = int(value)
    if ivalue < 1:
        raise argparse.ArgumentTypeError(
            "%s is not a positive integer" % value)
    return ivalue

def check_valid_size(value):
    """Check that the argument is a valid size for a mutilated board."""
    ivalue = int(value)
    if ivalue < 2:
        raise argparse.ArgumentTypeError(
            "%s is not a valid board size" % value)
    return ivalue

def parseArgs():
    """Parse command line."""
    parser = argparse.ArgumentParser(
        description="Solve the mutilated chessboard problem",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("-n", "--number", help="side of the board",
                        type=check_valid_size, default=4)
    parser.add_argument("-v", "--verbose", help="increase output verbosity",
                        action="count", default=0)
    parser.add_argument("-r", "--reduction", help="apply symmetry reduction",
                        action="store_true")
    parser.add_argument("--reorder", help="reorder BDD variables",
                        action="store_true")
    parser.add_argument("--stats", help="print BDD stats", action="store_true")
    parser.add_argument("-m", "--memory", help="target maximum memory",
                        type=check_positive_number, default=0)
    return parser.parse_args()

def build_pieces():
    muticube = ~X[0][0] & ~Y[0][0] & ~X[N-1][N-2] & ~Y[N-2][N-1]
    if args.reduction:
        muticube &= X[0][N-2]
    pieces = []
    for i in range(N):
        for j in range(N):
            # Skip missing squares.
            if (i != 0 or j != 0) and (i != N-1 or j != N-1):
                vars = []
                if j != 0:
                    vars.append(X[i][j-1])
                if j != N-1:
                    vars.append(X[i][j])
                if i != 0:
                    vars.append(Y[i-1][j])
                if i != N-1:
                    vars.append(Y[i][j])
                pieces.append(mgr.cardinality(vars,1).cofactor(muticube))
    return pieces

def print_dependencies(lst):
    """Print a dependence matrix."""
    for b in lst:
        c = b.support().cube()
        print(''.join([' ' if x == 2 else str(x) for x in c]))    

def quantification_schedule(lst):
    """Compute quantification schedule."""
    last = [None] * mgr.size()
    for i in range(len(lst)):
        cube = lst[i].support().cube()
        for j in range(len(cube)):
            if cube[j] == 1:
                last[j] = i
    if args.verbose > 1:
        print(last)
    cubes = [mgr.bddOne() for i in range(len(lst))]
    for i in range(len(last)):
        if not last[i] is None:
            cubes[last[i]] &= mgr.bddVar(i)
    if args.verbose > 0:
        print(cubes)
    return cubes

def reduce_list(lst,cubes):
    """Destructively reduce a list of BDDs to their conjunction."""
    if len(lst) > 0:
        lst[0] = lst[0].existAbstract(cubes[0])
        i = 1
    while len(lst) > 1:
        lst[1] = lst[0].andAbstract(lst[1],cubes[i])
        i += 1
        lst.pop(0)
        if args.verbose > 0:
            if args.verbose > 1:
                lst[0].summary(name=str(len(lst)))
            else:
                print(len(lst), ': ', lst[0].size(), sep='')

def build_constraints():
    """Build the BDD for the tile placements."""
    pieces = build_pieces()

    if args.verbose > 1:
        print_dependencies(pieces)

    cubes = quantification_schedule(pieces)

    reduce_list(pieces,cubes)

    return pieces[0]

def print_report():
    "Print result."
    print('Solution count =', constraints.count())

if __name__ == '__main__':

    args = parseArgs()

    N = args.number

    mgr = Cudd(bddVars=N*N, maxMem=args.memory)
    mgr.minimizeDeathRow()

    if args.reorder:
        # Enable dynamic reordering.
        mgr.enableReorderingReporting()
        mgr.autodynEnable()
        mgr.printBddOrder()

    X = [[mgr.bddVar(2*(i*N+j),   'X_%s_%s' % (i, j)) for j in range(N-1)]
         for i in range(N)]
    Y = [[mgr.bddVar(2*(i*N+j)+1, 'Y_%s_%s' % (i, j)) for j in range(N)]
         for i in range(N-1)]

    if args.verbose > 0: print('Number of variables = ', mgr.size())

    constraints = build_constraints()
    print_report()
    if args.reorder:
        mgr.printBddOrder()
    if args.stats:
        mgr.printInfo()
